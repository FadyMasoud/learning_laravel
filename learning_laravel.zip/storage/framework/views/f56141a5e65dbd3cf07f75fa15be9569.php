
<?php 
$name = 'Sally';

?>

<h1>About Me - <?php echo e($name); ?></h1>
<p>This is my first Laravel page!</p><?php /**PATH C:\xampp\htdocs\learning_laravel\resources\views/about.blade.php ENDPATH**/ ?>