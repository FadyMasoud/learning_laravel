<footer class="bg-dark text-white text-center py-3 fixed-bottom">
    <p>© 2025 MySite | All Rights Reserved</p>
</footer>